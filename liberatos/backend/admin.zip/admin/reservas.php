<?php
session_start();
if (!isset($_SESSION["rol"]) || !in_array($_SESSION["rol"], ["Administrador", "Repartidor"])) {
    header("Location: login.php");
    exit;
}

include_once __DIR__ . '/../Clases/ReservaAdmin.php';
$reserva = new ReservaAdmin();
$stmt = $reserva->listarReservas();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>🗓️ Reservas | Liberatos</title>
  <style>
    body { font-family: "Poppins", sans-serif; background: #fefcfb; margin: 0; padding: 2rem; }
    h1 { color: #ff7f11; }
    .btn { background: #ff7f11; color: white; border: none; padding: 6px 12px; border-radius: 6px;
           text-decoration: none; font-size: 14px; transition: 0.3s; cursor: pointer; }
    .btn:hover { background: #e26c00; }
    table { width: 100%; border-collapse: collapse; margin-top: 1rem; background: white;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
    th { background: #ff7f11; color: white; }
    tr:hover { background: #fff3e6; }
  </style>
</head>
<body>
  <a href="dashboard.php" class="btn">⬅️ Volver atrás</a>
  <h1>Gestión de Reservas</h1>

  <table>
    <tr>
      <th>ID</th><th>Nombre</th><th>Correo</th><th>Personas</th>
      <th>Fecha</th><th>Mensaje</th><th>Estado</th><th>Acciones</th>
    </tr>
    <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
      <tr>
        <td><?= htmlspecialchars($row['id']) ?></td>
        <td><?= htmlspecialchars($row['nombre']) ?></td>
        <td><?= htmlspecialchars($row['correo']) ?></td>
        <td><?= htmlspecialchars($row['personas']) ?></td>
        <td><?= htmlspecialchars($row['fecha']) ?></td>
        <td><?= htmlspecialchars($row['mensaje']) ?></td>
        <td><?= htmlspecialchars($row['estado'] ?? 'pendiente') ?></td>
        <td>
          <?php if (($row['estado'] ?? 'pendiente') === 'pendiente'): ?>
            <button class="btn" onclick="accionReserva(<?= $row['id'] ?>, 'atendida')">✅ Atendida</button>
          <?php endif; ?>
          <button class="btn" style="background:#d9534f" onclick="accionReserva(<?= $row['id'] ?>, 'eliminar')">🗑️ Eliminar</button>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>

  <script>
    async function accionReserva(id, accion) {
      if (!confirm("¿Seguro que quieres realizar esta acción?")) return;
      const formData = new FormData();
      formData.append('id', id);
      formData.append('accion', accion);
      const res = await fetch('reserva_accion.php', { method: 'POST', body: formData });
      const texto = await res.text();
      alert(texto);
      location.reload();
    }
  </script>
</body>
</html>
