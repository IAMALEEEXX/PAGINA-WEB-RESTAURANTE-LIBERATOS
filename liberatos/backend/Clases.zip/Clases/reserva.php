<?php
require_once '../config/database.php'; // Asegúrate de que esta ruta sea correcta

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $conn = $db->connect();

    $nombre   = $_POST['nombre'] ?? '';
    $correo   = $_POST['correo'] ?? '';
    $personas = $_POST['personas'] ?? '';
    $fecha    = $_POST['fecha'] ?? '';
    $mensaje  = $_POST['mensaje'] ?? '';

    // Validar campos obligatorios
    if (empty($nombre) || empty($correo) || empty($personas) || empty($fecha)) {
        echo "❌ Todos los campos obligatorios deben completarse.";
        exit;
    }

    // Convertir fecha al formato MySQL
    $fecha_mysql = date('Y-m-d H:i:s', strtotime($fecha));

    $stmt = $conn->prepare("INSERT INTO reservas (nombre, correo, personas, fecha, mensaje, fecha_registro)
                            VALUES (:nombre, :correo, :personas, :fecha, :mensaje, NOW())");

    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':correo', $correo);
    $stmt->bindParam(':personas', $personas);
    $stmt->bindParam(':fecha', $fecha_mysql);
    $stmt->bindParam(':mensaje', $mensaje);

    if ($stmt->execute()) {
        echo "✅ Reserva guardada correctamente";
    } else {
        echo "❌ Error al guardar la reserva.";
    }
}
?>
