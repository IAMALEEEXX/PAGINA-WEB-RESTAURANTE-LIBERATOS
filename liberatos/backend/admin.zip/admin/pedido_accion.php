<?php
require_once __DIR__ . '/../config/Database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    $id = intval($_POST['id'] ?? 0);

    $db = new Database();
    $conn = $db->connect();

    if ($accion === 'eliminar') {
        $stmt = $conn->prepare("DELETE FROM pedidos WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo "✅ Pedido eliminado correctamente.";
    } elseif ($accion === 'entregado') {
        $stmt = $conn->prepare("UPDATE pedidos SET estado = 'entregado' WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo "✅ Pedido marcado como entregado.";
    } else {
        echo "❌ Acción no válida.";
    }
}
?>
