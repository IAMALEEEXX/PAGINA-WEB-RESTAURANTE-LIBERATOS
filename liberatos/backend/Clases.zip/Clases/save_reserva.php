<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// === CONEXIÓN A LA BASE DE DATOS ===
$host = "localhost";
$db_name = "liberatos";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $db_name);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Error de conexión: " . $conn->connect_error]);
    exit;
}

// === OBTENER DATOS (JSON o POST) ===
$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    $data = $_POST;
}
if (!$data) {
    echo json_encode(["success" => false, "message" => "No se recibieron datos"]);
    exit;
}

// === EXTRAER Y VALIDAR DATOS ===
$nombre   = trim($data["nombre"] ?? "");
$correo   = trim($data["correo"] ?? "");
$personas = isset($data["personas"]) ? (int)$data["personas"] : 1;
$fecha    = trim($data["fecha"] ?? "");
$mensaje  = trim($data["mensaje"] ?? "");

if ($nombre === "") {
    echo json_encode(["success" => false, "message" => "Falta el nombre"]);
    exit;
}

// Si no hay fecha o es inválida, usar la actual
if ($fecha === "" || strtotime($fecha) === false) {
    $fecha = date("Y-m-d H:i:s");
} else {
    $fecha = date("Y-m-d H:i:s", strtotime($fecha));
}

// === CONSULTA SQL ===
$sql = "INSERT INTO reservas (nombre, correo, personas, fecha, mensaje, fecha_registro)
        VALUES (?, ?, ?, ?, ?, NOW())";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssiss", $nombre, $correo, $personas, $fecha, $mensaje);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Reserva guardada correctamente",
        "data" => [
            "nombre" => $nombre,
            "correo" => $correo,
            "personas" => $personas,
            "fecha" => $fecha,
            "mensaje" => $mensaje
        ]
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
