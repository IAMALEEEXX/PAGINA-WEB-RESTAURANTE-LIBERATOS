<?php
require_once __DIR__ . '/../config/Database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    $id = intval($_POST['id'] ?? 0);

    $db = new Database();
    $conn = $db->connect();

    if ($accion === 'eliminar') {
        $stmt = $conn->prepare("DELETE FROM reservas WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo "✅ Reserva eliminada correctamente.";
    } elseif ($accion === 'atendida') {
        $stmt = $conn->prepare("UPDATE reservas SET estado = 'atendida' WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo "✅ Reserva marcada como atendida.";
    } else {
        echo "❌ Acción no válida.";
    }
}
?>
