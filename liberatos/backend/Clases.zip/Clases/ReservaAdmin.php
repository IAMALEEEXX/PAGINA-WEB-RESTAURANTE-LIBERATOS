<?php
include_once __DIR__ . '/../config/Database.php';

class ReservaAdmin {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function listarReservas() {
        $sql = "SELECT id, nombre, correo, personas, fecha, mensaje, fecha_registro
                FROM reservas
                ORDER BY fecha_registro DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt;
    }
}
?>
