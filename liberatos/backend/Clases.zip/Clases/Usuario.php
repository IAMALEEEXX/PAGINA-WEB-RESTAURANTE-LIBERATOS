<?php
class Usuario {
    private $conn;
    private $table = "usuarios";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function login($correo, $password) {
        $query = "SELECT u.id, u.nombre, u.correo, u.password, r.nombre AS rol_nombre
                  FROM " . $this->table . " u
                  INNER JOIN roles r ON u.rol_id = r.id
                  WHERE u.correo = :correo
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":correo", $correo);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && hash('sha256', $password) === $user["password"]) {
            return $user;
        }
        return false;
    }

    public function registrar($nombre, $correo, $password, $rol_id) {
        $query = "INSERT INTO " . $this->table . " (nombre, correo, password, rol_id)
                  VALUES (:nombre, :correo, :password, :rol_id)";
        $stmt = $this->conn->prepare($query);
        $passwordHash = hash('sha256', $password);

        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":correo", $correo);
        $stmt->bindParam(":password", $passwordHash);
        $stmt->bindParam(":rol_id", $rol_id);

        return $stmt->execute();
    }
}
?>
