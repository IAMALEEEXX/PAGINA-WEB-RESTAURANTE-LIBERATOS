<?php
session_start();
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "Administrador") {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración | Liberatos</title>
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #fff7ef;
      margin: 0;
      padding: 0;
    }
    header {
      background: #ff7f11;
      color: white;
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h1 { margin: 0; }
    .btn {
      background: white;
      color: #ff7f11;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s;
    }
    .btn:hover { background: #ffe8d1; }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
      padding: 2rem;
    }
    .card {
      background: white;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      padding: 1.5rem;
      text-align: center;
    }
    .card h3 {
      color: #ff7f11;
    }
  </style>
</head>
<body>
<header>
  <h1>🍔 Liberatos | Panel Admin</h1>
  <a href="logout.php" class="btn">Cerrar sesión</a>
</header>

<div class="grid">
  <div class="card">
      <h3>👥 Usuarios</h3>
      <p>Gestiona administradores, empleados y repartidores.</p>
      <a href="usuarios.php" class="btn">Ver usuarios</a>
  </div>
  <div class="card">
      <h3>📦 Pedidos</h3>
      <p>Visualiza todos los pedidos realizados.</p>
      <a href="pedidos.php" class="btn">Ver pedidos</a>
  </div>
  <div class="card">
      <h3>🗓️ Reservas</h3>
      <p>Consulta las reservas de clientes.</p>
      <a href="reservas.php" class="btn">Ver reservas</a>
  </div>
</div>
</body>
</html>
