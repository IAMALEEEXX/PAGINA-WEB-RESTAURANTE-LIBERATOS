<?php
session_start();
include_once "../config/Database.php";
include_once "../Clases/Usuario.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $database = new Database();
    $db = $database->connect();

    $usuario = new Usuario($db);

    $correo = $_POST["correo"];
    $password = $_POST["password"];

    $userData = $usuario->login($correo, $password);

    if ($userData) {
        $_SESSION["usuario_id"] = $userData["id"];
        $_SESSION["nombre"] = $userData["nombre"];
        $_SESSION["rol"] = $userData["rol_nombre"];

        if ($userData["rol_nombre"] == "Administrador") {
            header("Location: dashboard.php");
        } elseif ($userData["rol_nombre"] == "Empleado") {
            header("Location: pedidos.php");
        } else {
            header("Location: reservas.php");
        }
        exit;
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login | Liberatos</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #ff7f11, #ffb347);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .login-box {
            background: #fff;
            width: 380px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.25);
            padding: 2rem;
            text-align: center;
        }
        .login-box h2 {
            color: #ff7f11;
            margin-bottom: 1rem;
        }
        .login-box form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .login-box input {
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
        }
        .login-box button {
            background: #ff7f11;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            transition: background 0.3s;
        }
        .login-box button:hover {
            background: #ff6600;
        }
        .error {
            color: red;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        .footer {
            margin-top: 1rem;
            font-size: 0.85rem;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>🍔 Liberatos Admin</h2>
        <p>Inicia sesión para gestionar pedidos y reservas</p>

        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="POST">
            <input type="email" name="correo" placeholder="Correo electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Ingresar</button>
        </form>

        <div class="footer">© Liberatos 2025</div>
    </div>
</body>
</html>
