<?php
// backend/Clases/Pedido.php

header("Content-Type: text/plain; charset=UTF-8");

// Verifica que sea método POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Conexión a la base de datos
    $conn = new mysqli("localhost", "root", "", "liberatos");
    if ($conn->connect_error) {
        die("❌ Error de conexión: " . $conn->connect_error);
    }

    // Recibir datos del formulario
    $nombre     = $conn->real_escape_string($_POST['nombre']);
    $telefono   = $conn->real_escape_string($_POST['telefono']);
    $correo     = $conn->real_escape_string($_POST['correo']);
    $direccion  = $conn->real_escape_string($_POST['direccion']);
    $categoria  = $conn->real_escape_string($_POST['categoria']);
    $plato      = $conn->real_escape_string($_POST['plato']);
    $cantidad   = (int)$_POST['cantidad'];

    // Validación básica
    if (empty($nombre) || empty($telefono) || empty($correo) || empty($direccion) || empty($categoria) || empty($plato)) {
        echo "❌ Faltan campos obligatorios.";
        exit;
    }

    // Insertar el pedido
    $sql = "INSERT INTO pedidos (nombre, telefono, correo, direccion, categoria, plato, cantidad, fecha)
            VALUES ('$nombre', '$telefono', '$correo', '$direccion', '$categoria', '$plato', '$cantidad', NOW())";

    if ($conn->query($sql) === TRUE) {
        echo "✅ Pedido guardado correctamente.";
    } else {
        echo "❌ Error al guardar: " . $conn->error;
    }

    $conn->close();

} else {
    echo "❌ Método no permitido.";
}
?>
