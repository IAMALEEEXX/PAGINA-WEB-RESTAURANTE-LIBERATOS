<?php
session_start();
include_once "../config/Database.php";
include_once "../Clases/Usuario.php";
include_once "../Clases/Rol.php";

if (!isset($_SESSION["rol"]) || $_SESSION["rol"] != "Administrador") {
    header("Location: login.php");
    exit;
}

$database = new Database();
$db = $database->connect();

$usuario = new Usuario($db);
$rol = new Rol($db);

$roles = $rol->listarRoles();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $password = $_POST["password"];
    $rol_id = $_POST["rol_id"];

    if ($usuario->registrar($nombre, $correo, $password, $rol_id)) {
        $mensaje = "✅ Usuario registrado correctamente.";
    } else {
        $mensaje = "❌ Error al registrar usuario.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios | Liberatos</title>
</head>
<body>
    <h2>Registrar Nuevo Usuario</h2>
    <?php if (!empty($mensaje)) echo "<p>$mensaje</p>"; ?>

    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>

        <label>Correo:</label>
        <input type="email" name="correo" required>

        <label>Contraseña:</label>
        <input type="password" name="password" required>

        <label>Rol:</label>
        <select name="rol_id" required>
            <option value="">-- Selecciona Rol --</option>
            <?php foreach ($roles as $r): ?>
                <option value="<?= $r['id'] ?>"><?= $r['nombre'] ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Registrar</button>
    </form>
</body>
</html>
