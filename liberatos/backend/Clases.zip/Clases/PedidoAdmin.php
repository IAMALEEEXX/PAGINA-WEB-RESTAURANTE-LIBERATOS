<?php
include_once __DIR__ . '/../config/Database.php';

class PedidoAdmin {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function listarPedidos() {
        $sql = "SELECT id, nombre, telefono, correo, direccion, categoria, plato, cantidad, fecha
                FROM pedidos
                ORDER BY fecha DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt;
    }
}
?>
